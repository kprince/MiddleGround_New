//
//  RewardVideoViewController.h
//  GDTMobApp
//
//  Created by royqpwang on 2018/9/5.
//  Copyright © 2018年 Tencent. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GetDeepLink : NSObject
//- (void)getDeepLink:(const char*) name;
@end

